complie instructions in the report
